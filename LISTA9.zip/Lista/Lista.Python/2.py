palavra = input("Digite uma palavra de até 10 caracteres: ")
ultimo_caractere = palavra[-1]
print("O último caractere da palavra é:", ultimo_caractere)