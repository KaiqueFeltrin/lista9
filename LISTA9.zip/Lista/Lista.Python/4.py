letra_maiuscula = input("Digite uma letra maiúscula: ")
letra_minuscula = chr(ord(letra_maiuscula) + 32)
print(f"A letra minúscula correspondente é {letra_minuscula}")