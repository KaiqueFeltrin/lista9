nome = input("Digite um nome: ")
print(nome[:4])