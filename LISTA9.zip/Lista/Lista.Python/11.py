nome = input("Digite um nome: ")

if nome.lower().startswith("a"):
    print(nome)
else:
    print("O nome não começa com 'a'.")