string1 = input("Digite a primeira string: ")
string2 = input("Digite a segunda string: ")

if string1 == string2:
    print("As duas strings são iguais.")
else:
    print("As duas strings são diferentes.")