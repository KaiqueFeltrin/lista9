nome = input("Digite um nome: ")
quantidade_letras = len(nome)
print(f"O nome {nome} tem {quantidade_letras} letras.")