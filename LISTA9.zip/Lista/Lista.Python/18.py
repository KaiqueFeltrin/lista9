for i in range(65, 91):
    new_char = chr(i - 32)
    print(new_char)
