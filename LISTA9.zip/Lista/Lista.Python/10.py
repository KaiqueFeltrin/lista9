string = input("Digite uma string: ")

nova_string = string.replace("0", "1")

print("Nova string: ", nova_string)