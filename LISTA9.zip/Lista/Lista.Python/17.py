string = input("Digite uma string: ")  
string_maiuscula = string.upper()  
print(string_maiuscula)  

