entrada = input("Digite uma cadeia de caracteres em maiúsculo: ")

saida = entrada.lower()

print("A cadeia de caracteres em minúsculo é: ", saida)
